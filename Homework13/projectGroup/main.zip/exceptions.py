class InvalidStudentAdd(Exception):
    pass